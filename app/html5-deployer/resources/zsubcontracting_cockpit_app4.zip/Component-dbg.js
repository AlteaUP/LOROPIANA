sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("zsubcontractingcockpitapp4.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);