sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("zsubcontractingcockpitapp4.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map